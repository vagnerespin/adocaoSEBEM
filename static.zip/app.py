
from flask import Flask, render_template, request, redirect, url_for, send_file
from models import init_db, salvar_adotante, buscar_adocoes_por_periodo
from datetime import datetime
import os

app = Flask(__name__)
init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        dados = {
            'nome': request.form['nome'],
            'cpf': request.form['cpf'],
            'telefone': request.form['telefone'],
            'email': request.form['email'],
            'endereco': request.form['endereco'],
            'animal': request.form['animal'],
            'data': request.form['data'],
            'observacoes': request.form['observacoes']
        }
        salvar_adotante(**dados)
        return redirect(url_for('index'))
    return render_template('cadastro_adotante.html')

@app.route('/relatorios', methods=['GET', 'POST'])
def relatorios():
    resultados = []
    if request.method == 'POST':
        inicio = request.form['data_inicio']
        fim = request.form['data_fim']
        resultados = buscar_adocoes_por_periodo(inicio, fim)
    return render_template('relatorios.html', resultados=resultados)

@app.route('/backup')
def backup():
    data = datetime.now().strftime('%Y-%m-%d_%H-%M')
    return send_file('adotantes.db', as_attachment=True, download_name=f'backup_adotantes_{data}.db')

@app.route('/restaurar', methods=['GET', 'POST'])
def restaurar():
    if request.method == 'POST':
        arquivo = request.files['arquivo']
        if arquivo.filename.endswith('.db'):
            arquivo.save('adotantes.db')
            return "Banco restaurado com sucesso!"
        else:
            return "Arquivo inválido."
    return render_template('restaurar.html')

if __name__ == '__main__':
    app.run(debug=True)
