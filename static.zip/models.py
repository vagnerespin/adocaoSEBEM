
import sqlite3

def init_db():
    conn = sqlite3.connect('adotantes.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS adotantes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf TEXT,
            telefone TEXT,
            email TEXT,
            endereco TEXT,
            animal TEXT,
            data TEXT,
            observacoes TEXT
        )
    ''')
    conn.commit()
    conn.close()

def salvar_adotante(nome, cpf, telefone, email, endereco, animal, data, observacoes):
    conn = sqlite3.connect('adotantes.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO adotantes (nome, cpf, telefone, email, endereco, animal, data, observacoes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                   (nome, cpf, telefone, email, endereco, animal, data, observacoes))
    conn.commit()
    conn.close()

def buscar_adocoes_por_periodo(inicio, fim):
    conn = sqlite3.connect('adotantes.db')
    cursor = conn.cursor()
    cursor.execute("SELECT nome, animal, data FROM adotantes WHERE data BETWEEN ? AND ?", (inicio, fim))
    dados = cursor.fetchall()
    conn.close()
    return dados
